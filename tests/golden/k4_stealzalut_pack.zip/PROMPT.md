You are grading the source image toward the reference style.

Analysis ID: 44edbdfc
Source zones: S1, S2, S3, S4, S5
Reference zones: R1, R2, R3, R4, R5

Rules:
- Match each source zone Sx to one or more reference zones Rx.
- Keep any zone that is clearly equivalent locked when appropriate.
- MULTIPLIENT: the final dose is the product of all strengths; a full intensity is the default, and the usual value for every link is "full".
- Garde 1.0 par défaut pour luminance_strength et chroma_strength; si you need to soften, prefer ≤ 0.5.
- N'invente AUCUNE valeur de couleur.
- Use a recipe format based on a JSON object with the field `format: "stealzalut.recipe"` and `version: 2`.
- The AI should emit a `links` array like {"source_zone": 1, "targets": {"2": 0.7, "3": 0.3}, "strength": "full", "luminance_strength": 1.0, "chroma_strength": 1.0}.
- If the source zone should remain untouched, use `{"source_zone": 3, "keep": true}`.
- PLEIN effet = "full"; if a tone must be less assertive, use "strong" or "medium".

```json
{
  "format": "stealzalut.recipe",
  "version": 2,
  "analysis_id": "44edbdfc",
  "mode": "zones",
  "links": [
    {"source_zone": 1, "targets": {"1": 1.0}, "strength": "full", "luminance_strength": 1.0, "chroma_strength": 1.0}
  ],
  "finishing": {"saturation": 0.0, "vibrance": 0.0}
}
```
